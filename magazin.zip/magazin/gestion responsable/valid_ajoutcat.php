<?php
mysql_connect("localhost","root","");
mysql_select_db("magazin")or die("erreur bd");
$libelle=$_POST['libelle'];
$req="insert into categorie(id,libelle)
 values('','$libelle')";
$res=mysql_query($req) or die("erreur req");
if($res)
header("location:categorie.php");
?>