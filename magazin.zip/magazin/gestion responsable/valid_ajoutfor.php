<?php
mysql_connect("localhost","root","");
mysql_select_db("magazin")or die("erreur bd");
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$num_tel=$_POST['Num_tel'];
$adresse=$_POST['Adresse'];
$req="insert into fournisseur(id,nom,prenom,num_tel,adresse)
 values('','$nom','$prenom','$num_tel','$adresse')";
$res=mysql_query($req) or die("erreur req");
if($res)
header("location:fournisseur.php");
?>