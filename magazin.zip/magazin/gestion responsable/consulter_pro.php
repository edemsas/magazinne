



<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Gestion Responsable</title>
    <!-- Sets initial viewport load and disables zooming  -->
    <meta name="viewport" content="initial-scale=1, maximum-scale=1, user-scalable=no">
    <!-- SmartAddon.com Verification -->
    <meta name="smartaddon-verification" content="936e8d43184bc47ef34e25e426c508fe" />
	<meta name="keywords" content="Flat UI Design, UI design, UI, user interface, web interface design, user interface design, Flat web design, Bootstrap, Bootflat, Flat UI colors, colors">
	<meta name="description" content="The complete style of the Bootflat Framework.">
    <link rel="shortcut icon" href="favicon_16.ico"/>
    <link rel="bookmark" href="favicon_16.ico"/>
    <!-- site css -->
    <link rel="stylesheet" href="../css/site.min.css">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,800,700,400italic,600italic,700italic,800italic,300italic" rel="stylesheet" type="text/css">
    <!-- <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'> -->
    <!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
    <script type="text/javascript" src="js/site.min.js"></script>
  </head>
<body >
<!--documents-->
    <div class="container documents">
      <!-- Color Swatches
      ================================================== -->
 <nav class="navbar navbar-inverse" role="navigation">
                  <div class="container-fluid">
                    <div class="navbar-header">
                      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-8">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                      </button>
                      <a class="navbar-brand" href="#">&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp; Bienvenue Responsable</a>&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;
                    </div>
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-8">
                      <center><a href="../index.html"><button type="button" class="btn btn-danger navbar-btn">Déconnecté</button> </a></center>
                    </div>
                  </div>
                </nav>
                </div>
  
 <center> <h2><strong><em>Gestion Produit</em></strong></h2></center>
<!-- Save for Web Slices (projet.psd) -->
<table id="Tableau_01" width="750" height="625" border="0" cellpadding="0" cellspacing="0" align="center">
	<tr>
		
	</tr>
	<tr>
		<td background="../images/admin_02.png" width="750" height="460" alt="">
       <div>
       
<br><br>
        <center>    
        
        <h3>Consulter un Produit</h3>
        <div class="row">
              <div class="col-md-12">
              <?php
$id=$_GET['id'];
$link = @mysql_connect( 'localhost', 'root', '');
mysql_select_db("magazin");
$req="select * from produit where id='$id'";
$res=mysql_query($req);
$t=mysql_fetch_array($res);
?>
               
        <table >
                
         
    <tr><td><h5>Libelle</h5> </td><td><input type="text" class="form-control" disabled placeholder="Text input"  value="<?php echo $t[1]; ?>" required></td>
    <tr><td><h5>Qantite</h5> </td><td><input type="text" class="form-control" disabled placeholder="Text input" value="<?php echo $t[2]; ?>" required></td>
    <tr><td><h5>Prix</h5> </td><td><input type="text" class="form-control" disabled placeholder="Text input" value="<?php echo $t[3]; ?>" required></td>
   
       
      
      <tr>
       <td><a href="produit.php"> <button  type="button" class='btn btn-warning' >Retour</button></td>
       </tr>
       
        </form> 
        
        </table>
      
        </div>
        </td>
	</tr>
	<tr>
		<td>&nbsp;</td>
	</tr>
</table>
</div>
        

<!-- End Save for Web Slices -->
</body>
</html>


