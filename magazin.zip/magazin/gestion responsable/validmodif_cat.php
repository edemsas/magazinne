<?php
mysql_connect("127.0.0.1", "root", "");
mysql_select_db("magazin");
$id=$_POST['id'];
$libelle=$_POST['Libelle'];
$req="update categorie
set 
libelle='$Libelle'
where id=$id";
$res=mysql_query($req) or die ("probleme de requet");
if($res)
header("location:https://categorie.php") or die ("c faux");
?>