<?php
mysql_connect("localhost","root","");
mysql_select_db("magazin")or die("erreur bd");
$libelle=$_POST['libelle'];
$qantite=$_POST['qantite'];
$prix=$_POST['prix'];
$req="insert into produit(id,libelle,qantite,Prix)
 values('','$libelle','$qantite','$prix')";
$res=mysql_query($req) or die("erreur req");
if($res)
header("location:produit.php");
?>