<?php
mysql_connect("127.0.0.1", "root", "");
mysql_select_db("magazin");
$id=$_POST['id'];
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$num_tel=$_POST['num_tel'];
$adresse=$_POST['adresse'];
$req="update fournisseur
set 
nom='$nom',
prenom='$prenom',
num_tel='$num_tel',
adresse='$adresse'
where id=$id";
$res=mysql_query($req) or die ("probleme de requet");
if($res)
header("location:fournisseur.php") or die ("c faux");
?>