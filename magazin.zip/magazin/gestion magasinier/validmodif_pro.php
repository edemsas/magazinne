<?php
mysql_connect("127.0.0.1", "root", "");
mysql_select_db("magazin");
$id=$_POST['id'];
$libelle=$_POST['libelle'];
$qantite=$_POST['qantite'];
$prix=$_POST['prix'];
$req="update produit
set 
libelle='$libelle',
qantite='$qantite',
prix='$prix'
where id=$id";
$res=mysql_query($req) or die ("probleme de requet");
if($res)
header("location:index.php") or die ("c faux");
?>