<?php
$id=$_GET['id'];
mysql_connect("localhost","root","");
mysql_select_db("magazin") or die("erreur bd");
$req="delete from admin where id=".$id;
if (mysql_query($req))
		header("location: index.php");


?>