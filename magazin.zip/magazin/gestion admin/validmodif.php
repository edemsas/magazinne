<?php
mysql_connect("127.0.0.1", "root", "");
mysql_select_db("magazin");
$id=$_POST['id'];
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$email=$_POST['email'];
$pwd=$_POST['pwd'];
$type=$_POST['type'];
$req="update admin
set 
nom='$nom',
prenom='$prenom',
email='$email',
pwd='$pwd',
type='$type'
where id=$id";
$res=mysql_query($req) or die ("probleme de requet");
if($res)
header("location:index.php") or die ("c faux");
?>