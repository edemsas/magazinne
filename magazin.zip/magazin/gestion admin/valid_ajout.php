<?php
mysql_connect("localhost","root","");
mysql_select_db("magazin")or die("erreur bd");
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$email=$_POST['email'];
$pwd=$_POST['pwd'];
$type=$_POST['type'];
$req="insert into admin(id,nom,prenom,email,pwd,type)
 values('','$nom','$prenom','$email','$pwd','$type')";
$res=mysql_query($req) or die("erreur req");
if($res)
header("location:index.php");
?>